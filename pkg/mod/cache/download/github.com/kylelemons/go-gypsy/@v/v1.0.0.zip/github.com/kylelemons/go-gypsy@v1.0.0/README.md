Simple YAML-like Configs
========================

[![PkgGoDev](https://pkg.go.dev/badge/github.com/kylelemons/go-gypsy/yaml)](https://pkg.go.dev/github.com/kylelemons/go-gypsy/yaml)
[![GoDoc](https://godoc.org/github.com/kylelemons/go-gypsy/yaml?status.svg)](https://godoc.org/github.com/kylelemons/go-gypsy/yaml)
[![Build Status](https://travis-ci.com/kylelemons/go-gypsy.svg?branch=master)](https://travis-ci.com/kylelemons/go-gypsy)

This repository contains a very simple parser for a YAML-like config language.
Check out the API and the spec on [GoDoc](https://godoc.org/github.com/kylelemons/go-gypsy).
